import sys
import xbmcgui
import xbmcplugin

# Este es un addon puente para lanzar Fen con tus filtros
handle = int(sys.argv[1])
xbmcgui.Dialog().notification('Personal', 'Cargando contenido en Español...', xbmcgui.NOTIFICATION_INFO, 5000)
# Aquí podrías añadir un menú directo a GranTorrent