# -*- coding: utf-8 -*-
import re
from cocoscrapers.modules import client

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['es']
        self.domains = ['grantorrent.wtf', 'grantorrent.ch']
        self.base_link = 'https://grantorrent.wtf'
        self.search_link = '/buscar?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # Forzamos búsqueda por título en español
            search_id = localtitle.replace(' ', '+')
            url = self.base_link + self.search_link % search_id
            html = client.request(url)
            # Extracción de enlaces (simplificada para el ejemplo)
            results = re.compile(r'<a href="([^"]+)" class="text-white">([^<]+)</a>').findall(html)
            return [res[0] for res in results if year in res[1]]
        except: return []