# -*- coding: utf-8 -*-
import re
from cocoscrapers.modules import client
from cocoscrapers.modules import source_utils

class source:
    def __init__(self):
        self.priority = 2
        self.language = ['es']
        self.base_link = 'https://mejortorrent.wtf' # El dominio puede variar
        self.search_link = '/busqueda?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = localtitle.replace(' ', '+')
            url = self.base_link + self.search_link % search_id
            html = client.request(url)
            
            # Buscamos los resultados de la búsqueda
            results = re.compile(r'<a href="(/peli-descargar/[^"]+)" title="([^"]+)"', re.DOTALL).findall(html)
            
            items = []
            for link, name in results:
                if year in name or localtitle.lower() in name.lower():
                    # Entramos a la página de descarga para obtener el magnet
                    item_page = client.request(self.base_link + link)
                    magnet = re.search(r'href="(magnet:\?xt=urn:btih:[^"]+)"', item_page)
                    
                    if magnet:
                        items.append({
                            'title': name,
                            'link': magnet.group(1),
                            'source': 'MejorTorrent',
                            'quality': source_utils.get_release_quality(name, magnet.group(1))[0]
                        })
            return items
        except:
            return []