# -*- coding: utf-8 -*-
import re
from cocoscrapers.modules import client
from cocoscrapers.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['es']
        # El dominio cambia a veces (.org, .com, .li, .cat)
        self.base_link = 'https://dontorrent.org' 
        self.search_link = '/buscar/%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # En tu addon personal, buscamos por el título en español
            search_id = localtitle.replace(' ', '+')
            url = self.base_link + self.search_link % search_id
            
            html = client.request(url)
            
            # Buscamos los enlaces de las películas en el listado
            # Expresión regular para capturar el link y el nombre
            results = re.compile(r'href="(/pelicula/[^"]+)" title="([^"]+)"', re.DOTALL).findall(html)
            
            links = []
            for link, name in results:
                # Verificamos que el año coincida para no bajar versiones viejas
                if year in name:
                    item_url = self.base_link + link
                    html_item = client.request(item_url)
                    
                    # Extraemos el magnet link
                    magnet = re.search(r'href="(magnet:\?xt=urn:btih:[^"]+)"', html_item)
                    if magnet:
                        links.append({
                            'title': name,
                            'link': magnet.group(1),
                            'source': 'DonTorrent',
                            'quality': source_utils.get_release_quality(name, magnet.group(1))[0]
                        })
            return links
        except:
            return []